import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Users,
  FileText,
  Calendar,
  HelpCircle,
  BarChart3,
  Settings,
  Shield,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Search,
  Filter,
  Download,
  ArrowLeft,
  Eye,
  Ban,
  Trash2,
  Edit,
  TrendingUp,
  Activity,
  UserCheck,
  Flag,
} from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { useApp } from './AppContext';
import RankBadge from './RankBadge';
import { toast } from 'sonner@2.0.3';

const METROPOLIS_FONT = "'Metropolis', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif";

interface AdminPanelProps {
  onBack: () => void;
}

export default function AdminPanel({ onBack }: AdminPanelProps) {
  const { state } = useApp();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');

  // Calculate statistics
  const stats = {
    totalUsers: state.users.length,
    totalPosts: state.posts.length,
    totalEvents: state.events.length,
    totalHelpRequests: state.helpRequests.length,
    activeUsers: state.users.filter(u => u.isOnline).length,
    pendingRequests: state.helpRequests.filter(r => r.status === 'open').length,
    upcomingEvents: state.events.filter(e => e.status === 'upcoming').length,
    totalServicesOffered: state.servicesOffered.length,
  };

  // Dashboard Component
  const DashboardView = () => (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6 border-l-4 border-l-[#FF6F00]">
          <div className="flex items-center justify-between">
            <div>
              <p 
                className="text-sm text-gray-600 mb-1"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
              >
                Total Users
              </p>
              <p 
                className="text-3xl text-gray-900"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '700' }}
              >
                {stats.totalUsers}
              </p>
              <p 
                className="text-xs text-green-600 mt-1"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '500' }}
              >
                {stats.activeUsers} active
              </p>
            </div>
            <div className="w-12 h-12 bg-[#FFF3E0] rounded-full flex items-center justify-center">
              <Users className="w-6 h-6 text-[#FF6F00]" />
            </div>
          </div>
        </Card>

        <Card className="p-6 border-l-4 border-l-blue-500">
          <div className="flex items-center justify-between">
            <div>
              <p 
                className="text-sm text-gray-600 mb-1"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
              >
                Total Posts
              </p>
              <p 
                className="text-3xl text-gray-900"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '700' }}
              >
                {stats.totalPosts}
              </p>
              <p 
                className="text-xs text-blue-600 mt-1"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '500' }}
              >
                Seva activities
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center">
              <FileText className="w-6 h-6 text-blue-500" />
            </div>
          </div>
        </Card>

        <Card className="p-6 border-l-4 border-l-purple-500">
          <div className="flex items-center justify-between">
            <div>
              <p 
                className="text-sm text-gray-600 mb-1"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
              >
                Events
              </p>
              <p 
                className="text-3xl text-gray-900"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '700' }}
              >
                {stats.totalEvents}
              </p>
              <p 
                className="text-xs text-purple-600 mt-1"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '500' }}
              >
                {stats.upcomingEvents} upcoming
              </p>
            </div>
            <div className="w-12 h-12 bg-purple-50 rounded-full flex items-center justify-center">
              <Calendar className="w-6 h-6 text-purple-500" />
            </div>
          </div>
        </Card>

        <Card className="p-6 border-l-4 border-l-red-500">
          <div className="flex items-center justify-between">
            <div>
              <p 
                className="text-sm text-gray-600 mb-1"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
              >
                Help Requests
              </p>
              <p 
                className="text-3xl text-gray-900"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '700' }}
              >
                {stats.totalHelpRequests}
              </p>
              <p 
                className="text-xs text-red-600 mt-1"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '500' }}
              >
                {stats.pendingRequests} pending
              </p>
            </div>
            <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center">
              <HelpCircle className="w-6 h-6 text-red-500" />
            </div>
          </div>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 
            className="text-lg text-gray-900"
            style={{ fontFamily: METROPOLIS_FONT, fontWeight: '600' }}
          >
            Recent Activity
          </h3>
          <Button variant="outline" size="sm" style={{ fontFamily: METROPOLIS_FONT }}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>

        <div className="space-y-4">
          {state.posts.slice(0, 5).map((post) => {
            const user = state.users.find(u => u.id === post.userId);
            return (
              <div key={post.id} className="flex items-start gap-4 pb-4 border-b border-gray-100 last:border-0">
                <img
                  src={user?.avatar}
                  alt={user?.name}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span 
                      className="text-sm text-gray-900"
                      style={{ fontFamily: METROPOLIS_FONT, fontWeight: '600' }}
                    >
                      {user?.name}
                    </span>
                    <span 
                      className="text-xs text-gray-500"
                      style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
                    >
                      posted • {post.timestamp}
                    </span>
                  </div>
                  <p 
                    className="text-sm text-gray-700 line-clamp-2"
                    style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
                  >
                    {post.content}
                  </p>
                  <div className="flex items-center gap-4 mt-2">
                    <span className="text-xs text-gray-500">
                      ❤️ {post.likes} likes
                    </span>
                    <span className="text-xs text-gray-500">
                      💬 {post.comments.length} comments
                    </span>
                  </div>
                </div>
                <Badge variant="outline">{post.category}</Badge>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Charts Placeholder */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 
            className="text-lg text-gray-900 mb-4"
            style={{ fontFamily: METROPOLIS_FONT, fontWeight: '600' }}
          >
            User Growth
          </h3>
          <div className="h-48 bg-gray-50 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <TrendingUp className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p 
                className="text-sm text-gray-500"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
              >
                Chart visualization coming soon
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h3 
            className="text-lg text-gray-900 mb-4"
            style={{ fontFamily: METROPOLIS_FONT, fontWeight: '600' }}
          >
            Activity Breakdown
          </h3>
          <div className="h-48 bg-gray-50 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <Activity className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p 
                className="text-sm text-gray-500"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
              >
                Chart visualization coming soon
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );

  // User Management Component
  const UserManagementView = () => {
    const filteredUsers = state.users.filter(user =>
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
      <div className="space-y-4">
        {/* Search and Filter */}
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search users..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              style={{ fontFamily: METROPOLIS_FONT }}
            />
          </div>
          <Button variant="outline" style={{ fontFamily: METROPOLIS_FONT }}>
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
        </div>

        {/* Users List */}
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th 
                    className="text-left px-6 py-3 text-xs text-gray-600"
                    style={{ fontFamily: METROPOLIS_FONT, fontWeight: '600' }}
                  >
                    User
                  </th>
                  <th 
                    className="text-left px-6 py-3 text-xs text-gray-600"
                    style={{ fontFamily: METROPOLIS_FONT, fontWeight: '600' }}
                  >
                    Rank
                  </th>
                  <th 
                    className="text-left px-6 py-3 text-xs text-gray-600"
                    style={{ fontFamily: METROPOLIS_FONT, fontWeight: '600' }}
                  >
                    Location
                  </th>
                  <th 
                    className="text-left px-6 py-3 text-xs text-gray-600"
                    style={{ fontFamily: METROPOLIS_FONT, fontWeight: '600' }}
                  >
                    Seva Points
                  </th>
                  <th 
                    className="text-left px-6 py-3 text-xs text-gray-600"
                    style={{ fontFamily: METROPOLIS_FONT, fontWeight: '600' }}
                  >
                    Status
                  </th>
                  <th 
                    className="text-right px-6 py-3 text-xs text-gray-600"
                    style={{ fontFamily: METROPOLIS_FONT, fontWeight: '600' }}
                  >
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={user.avatar}
                          alt={user.name}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                        <div>
                          <p 
                            className="text-sm text-gray-900"
                            style={{ fontFamily: METROPOLIS_FONT, fontWeight: '600' }}
                          >
                            {user.name}
                          </p>
                          <p 
                            className="text-xs text-gray-500"
                            style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
                          >
                            {user.email}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <RankBadge rank={user.rank} size="sm" />
                    </td>
                    <td className="px-6 py-4">
                      <span 
                        className="text-sm text-gray-700"
                        style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
                      >
                        {user.location}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span 
                        className="text-sm text-[#FF6F00]"
                        style={{ fontFamily: METROPOLIS_FONT, fontWeight: '600' }}
                      >
                        {user.sevaPoints.toLocaleString()}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      {user.isOnline ? (
                        <Badge className="bg-green-100 text-green-700">
                          Active
                        </Badge>
                      ) : (
                        <Badge variant="outline">
                          Offline
                        </Badge>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toast.success('View user details')}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toast.success('Edit user')}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toast.error('User suspended')}
                        >
                          <Ban className="w-4 h-4 text-red-600" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    );
  };

  // Content Moderation Component
  const ContentModerationView = () => {
    const [contentType, setContentType] = useState<'posts' | 'events' | 'services'>('posts');

    return (
      <div className="space-y-4">
        <Tabs value={contentType} onValueChange={(v) => setContentType(v as any)}>
          <TabsList>
            <TabsTrigger value="posts" style={{ fontFamily: METROPOLIS_FONT }}>
              Posts ({state.posts.length})
            </TabsTrigger>
            <TabsTrigger value="events" style={{ fontFamily: METROPOLIS_FONT }}>
              Events ({state.events.length})
            </TabsTrigger>
            <TabsTrigger value="services" style={{ fontFamily: METROPOLIS_FONT }}>
              Services ({state.servicesOffered.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="posts" className="space-y-4">
            {state.posts.map((post) => {
              const user = state.users.find(u => u.id === post.userId);
              return (
                <Card key={post.id} className="p-4">
                  <div className="flex items-start gap-4">
                    <img
                      src={user?.avatar}
                      alt={user?.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <span 
                            className="text-sm text-gray-900"
                            style={{ fontFamily: METROPOLIS_FONT, fontWeight: '600' }}
                          >
                            {user?.name}
                          </span>
                          <span 
                            className="text-xs text-gray-500 ml-2"
                            style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
                          >
                            {post.timestamp}
                          </span>
                        </div>
                        <Badge>{post.category}</Badge>
                      </div>
                      <p 
                        className="text-sm text-gray-700 mb-3"
                        style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
                      >
                        {post.content}
                      </p>
                      {post.image && (
                        <img
                          src={post.image}
                          alt="Post"
                          className="w-full h-48 object-cover rounded-lg mb-3"
                        />
                      )}
                      <div className="flex items-center gap-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toast.success('Post approved')}
                          style={{ fontFamily: METROPOLIS_FONT }}
                        >
                          <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
                          Approve
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toast.error('Post flagged')}
                          style={{ fontFamily: METROPOLIS_FONT }}
                        >
                          <Flag className="w-4 h-4 mr-2 text-yellow-600" />
                          Flag
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toast.error('Post removed')}
                          style={{ fontFamily: METROPOLIS_FONT }}
                        >
                          <Trash2 className="w-4 h-4 mr-2 text-red-600" />
                          Remove
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </TabsContent>

          <TabsContent value="events">
            <Card className="p-6">
              <p 
                className="text-center text-gray-500"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
              >
                {state.events.length} events to moderate
              </p>
            </Card>
          </TabsContent>

          <TabsContent value="services">
            <Card className="p-6">
              <p 
                className="text-center text-gray-500"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
              >
                {state.servicesOffered.length} services to moderate
              </p>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    );
  };

  // Settings Component
  const SettingsView = () => (
    <div className="space-y-6">
      <Card className="p-6">
        <h3 
          className="text-lg text-gray-900 mb-4"
          style={{ fontFamily: METROPOLIS_FONT, fontWeight: '600' }}
        >
          System Settings
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between py-3 border-b border-gray-100">
            <div>
              <p 
                className="text-sm text-gray-900"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '500' }}
              >
                User Registration
              </p>
              <p 
                className="text-xs text-gray-500"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
              >
                Allow new users to register
              </p>
            </div>
            <input type="checkbox" className="w-5 h-5" defaultChecked />
          </div>
          <div className="flex items-center justify-between py-3 border-b border-gray-100">
            <div>
              <p 
                className="text-sm text-gray-900"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '500' }}
              >
                Content Moderation
              </p>
              <p 
                className="text-xs text-gray-500"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
              >
                Require approval for new posts
              </p>
            </div>
            <input type="checkbox" className="w-5 h-5" />
          </div>
          <div className="flex items-center justify-between py-3 border-b border-gray-100">
            <div>
              <p 
                className="text-sm text-gray-900"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '500' }}
              >
                Email Notifications
              </p>
              <p 
                className="text-xs text-gray-500"
                style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
              >
                Send email notifications to users
              </p>
            </div>
            <input type="checkbox" className="w-5 h-5" defaultChecked />
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <h3 
          className="text-lg text-gray-900 mb-4"
          style={{ fontFamily: METROPOLIS_FONT, fontWeight: '600' }}
        >
          Seva Point Settings
        </h3>
        <div className="space-y-3">
          <div>
            <label 
              className="text-sm text-gray-700 mb-1 block"
              style={{ fontFamily: METROPOLIS_FONT, fontWeight: '500' }}
            >
              Points per Post
            </label>
            <Input
              type="number"
              defaultValue={10}
              className="max-w-xs"
              style={{ fontFamily: METROPOLIS_FONT }}
            />
          </div>
          <div>
            <label 
              className="text-sm text-gray-700 mb-1 block"
              style={{ fontFamily: METROPOLIS_FONT, fontWeight: '500' }}
            >
              Points per Event Participation
            </label>
            <Input
              type="number"
              defaultValue={50}
              className="max-w-xs"
              style={{ fontFamily: METROPOLIS_FONT }}
            />
          </div>
          <div>
            <label 
              className="text-sm text-gray-700 mb-1 block"
              style={{ fontFamily: METROPOLIS_FONT, fontWeight: '500' }}
            >
              Points per Help Request Fulfilled
            </label>
            <Input
              type="number"
              defaultValue={30}
              className="max-w-xs"
              style={{ fontFamily: METROPOLIS_FONT }}
            />
          </div>
        </div>
        <Button 
          className="mt-4 bg-[#FF6F00] hover:bg-[#E65100] text-white"
          style={{ fontFamily: METROPOLIS_FONT }}
        >
          Save Changes
        </Button>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Add Metropolis Font Import */}
      <style>
        {`
          @import url('https://fonts.googleapis.com/css2?family=Metropolis:wght@300;400;500;600;700;800;900&display=swap');
        `}
      </style>

      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 lg:px-6 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-[#FF6F00] to-[#E65100] rounded-lg flex items-center justify-center">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 
                    className="text-xl text-gray-900"
                    style={{ fontFamily: METROPOLIS_FONT, fontWeight: '700' }}
                  >
                    Admin Panel
                  </h1>
                  <p 
                    className="text-sm text-gray-500"
                    style={{ fontFamily: METROPOLIS_FONT, fontWeight: '400' }}
                  >
                    Manage HindaviSwarajya platform
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 lg:px-6 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger 
              value="dashboard" 
              className="flex items-center gap-2"
              style={{ fontFamily: METROPOLIS_FONT }}
            >
              <BarChart3 className="w-4 h-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger 
              value="users" 
              className="flex items-center gap-2"
              style={{ fontFamily: METROPOLIS_FONT }}
            >
              <Users className="w-4 h-4" />
              Users
            </TabsTrigger>
            <TabsTrigger 
              value="content" 
              className="flex items-center gap-2"
              style={{ fontFamily: METROPOLIS_FONT }}
            >
              <FileText className="w-4 h-4" />
              Content
            </TabsTrigger>
            <TabsTrigger 
              value="settings" 
              className="flex items-center gap-2"
              style={{ fontFamily: METROPOLIS_FONT }}
            >
              <Settings className="w-4 h-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <DashboardView />
          </TabsContent>

          <TabsContent value="users">
            <UserManagementView />
          </TabsContent>

          <TabsContent value="content">
            <ContentModerationView />
          </TabsContent>

          <TabsContent value="settings">
            <SettingsView />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
